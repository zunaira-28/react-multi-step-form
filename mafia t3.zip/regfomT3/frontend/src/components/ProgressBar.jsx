import React from "react";
import "./Progress.css";

export default function ProgressBar({ step, totalSteps }) {
  return (
    <div className="progress-container">
      <div className="progress-line"></div>

      {[...Array(totalSteps)].map((_, index) => {
        const current = index + 1;
        const isCompleted = current < step;
        const isActive = current === step;

        return (
          <div
            key={index}
            className={`progress-circle 
              ${isCompleted ? "completed" : ""} 
              ${isActive ? "active" : ""}`}
          ></div>
        );
      })}
    </div>
  );
}
