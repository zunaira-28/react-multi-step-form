export const countryCityData = {
  "Saudi Arabia": ["Jubail", "Jeddah", "Dammam", "Mecca", "Medina"],
  "Turkey": ["Istanbul", "Ankara", "Izmir", "Bursa"],
  "Pakistan": ["Karachi", "Lahore", "Islamabad", "Quetta", "Gujrat"]
};
