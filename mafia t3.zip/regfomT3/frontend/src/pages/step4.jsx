import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Step4({ form, setForm, setStep }) {
  const nav = useNavigate();
  const [error, setError] = useState("");

  const hobbyOptions = ["Reading", "Cooking", "Sports", "Traveling", "Other"];

  const toggleHobby = (hobby) => {
    let updated = [...(form.hobbies || [])];
    if (updated.includes(hobby)) {
      updated = updated.filter(h => h !== hobby);
    } else {
      updated.push(hobby);
    }
    setForm({ ...form, hobbies: updated });
  };

  const review = () => {
    if (!form.hobbies || form.hobbies.length === 0) {
      setError("Please select at least one hobby.");
      return;
    }
    setError("");
    setStep("summary");
    nav("/summary");
  };

  const back = () => {
    setStep(3);
    nav("/step3");
  };

  return (
    <div className="card fade-slide">
      <h2>Step 4: Preferences & Interests</h2>
      {error && <p className="error">{error}</p>}

      <div className="box">
        <label>Hobbies*</label>
        {hobbyOptions.map(hobby => (
          <label key={hobby} className="checkbox-row">
            <input
              type="checkbox"
              checked={form.hobbies?.includes(hobby)}
              onChange={() => toggleHobby(hobby)}
            />
            {hobby}
          </label>
        ))}

        {form.hobbies?.includes("Other") && (
          <input
            placeholder="Write your hobby..."
            value={form.otherHobby || ""}
            onChange={e => setForm({ ...form, otherHobby: e.target.value })}
          />
        )}
      </div>

      <div className="box">
        <label className="checkbox-row">
          <input
            type="checkbox"
            checked={form.newsletter}
            onChange={e => setForm({ ...form, newsletter: e.target.checked })}
          />
          Subscribe to newsletter / notifications
        </label>
      </div>

      <div className="btns">
        <button className="btn back" onClick={back}>Back</button>
        <button className="btn" onClick={review}>Review</button>
      </div>
    </div>
  );
}
