import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./success.css";

export default function Success({ form, setForm, setStep }) {
  const navigate = useNavigate();

  // Save user to localStorage
  useEffect(() => {
    const users = JSON.parse(localStorage.getItem("users")) || [];
    if (form?.email) {
      users.push(form);
      localStorage.setItem("users", JSON.stringify(users));
    }
  }, [form]);

  // Start Again
  const startAgain = () => {
    setForm({
      name: "",
      email: "",
      age: "",
      gender: "",
      country: "",
      city: "",
      username: "",
      password: "",
      confirmPassword: "",
      hobbies: [],
      otherHobby: "",
      newsletter: false,
    });
    setStep(1);
    localStorage.removeItem("form");
    localStorage.removeItem("step");

    navigate("/");
  };

 return (
    <div className="success-wrapper fade-slide">
      <div className="note-card">
        <h2 className="title">✨ Registration Successful! ✨</h2>

        <p className="cute-msg">
         <strong> Yayyyy! You’re officially registered!  
          
          Thank you for completing the form~</strong>
        </p>

        <div className="sparkles">✨ 🌸 ✨</div>

        <button className="cute-btn" onClick={startAgain}>
          Start Again 💗
        </button>
      </div>
    </div>
  );
}
