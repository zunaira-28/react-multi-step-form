import React from "react";
import { useNavigate } from "react-router-dom";

import "./sum.css";

export default function Summary({ form, setStep }) {
  const nav = useNavigate();

  // Edit goes back to Step1
  const editInfo = () => {
    setStep(1);
    nav("/"); // or "/step1" if your route is Step1
  };

  // Confirm goes to Success page with backend submission
  const submit = async () => {
    try {
      // Backend call for registration
      const res = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (res.ok) {
        // JWT store in localStorage
        localStorage.setItem("token", data.token);

        // Show browser message
        alert(data.message); // "Registration successful" from backend

        // Move to Success page
        setStep("success");
        nav("/success");
      } else {
        alert(data.message || "Registration failed");
      }
    } catch (err) {
      console.error(err);
      alert("Something went wrong!");
    }
  };

  // Row component for display
  const Row = ({ label, value }) => (
    <div className="row">
      <span className="label">{label}</span>
      <span className="value">{value}</span>
    </div>
  );

  return (
    <div className="card notebook">
      <h2 className="title">Review Your Details</h2>
      <div className="receipt-box">
        <Row label="Name:" value={form.name} />
        <Row label="Email:" value={form.email} />
        <Row label="Age:" value={form.age} />
        {form.gender && <Row label="Gender:" value={form.gender} />}
        <Row label="Country:" value={form.country} />
        <Row label="City:" value={form.city} />
        <Row label="Username:" value={form.username} />
        <Row
          label="Hobbies:"
          value={
            <>
              {form.hobbies?.join(", ")}
              {form.otherHobby && `, ${form.otherHobby}`}
            </>
          }
        />
        <Row
          label="📩 Newsletter:"
          value={form.newsletter ? "Subscribed 💌" : "No"}
        />
      </div>

      <div className="btns">
        <button className="btn back" onClick={editInfo}>
          Edit
        </button>
        <button className="btn" onClick={submit}>
          Confirm
        </button>
      </div>
    </div>
  );
}
