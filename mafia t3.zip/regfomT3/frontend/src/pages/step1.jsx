import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Step1({ form, setForm, setStep }) {
  const nav = useNavigate();
  const [error, setError] = useState("");

  // REGEX
  const nameRegex = /^[A-Za-z ]+$/;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // VALIDATION CHECKERS
  const validName = nameRegex.test(form.name);
  const validEmail = emailRegex.test(form.email);
  const validAge = form.age !== "";
  const validGender = form.gender !== "";

  const next = () => {
    if (!form.name || !form.email || !form.age || !form.gender) {
      setError("Please fill all required fields");
      return;
    }

    if (!validName) {
      setError("Please enter a valid name (alphabets only)");
      return;
    }

    if (!validEmail) {
      setError("Please enter a valid email (e.g., user@gmail.com)");
      return;
    }
    if (!validAge) {
      setError("Please enter a valid age (numbers only)");
      return;
    }

    setError("");
    setStep(2);
    nav("/step2");
  };

  return (
    <div className="card fade-slide">
      <h2> Step 1: Personal Info</h2>
      {error && <p className="error">{error}</p>}

      {/* NAME */}
      <div className="box">
        <label>Name*</label>
        <div className="input-wrapper">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Enter your name"
          />
          {validName && <span className="tick">✓</span>}
        </div>
      </div>

      {/* EMAIL */}
      <div className="box">
        <label>Email*</label>
        <div className="input-wrapper">
          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="user@gmail.com"
          />
          {validEmail && <span className="tick">✓</span>}
        </div>
      </div>

      {/* AGE */}
      <div className="box">
        <label>Age*</label>
        <div className="input-wrapper">
          <input
            type="number"
            value={form.age}
            onChange={(e) => setForm({ ...form, age: e.target.value })}
             
          />
          {validAge && <span className="tick">✓</span>}
        </div>
      </div>

      {/* GENDER */}
      <div className="box">
        <label>Gender*</label>
        <div className="input-wrapper">
          <select
            value={form.gender}
            onChange={(e) => setForm({ ...form, gender: e.target.value })}
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          {validGender && <span className="tick">✓</span>}
        </div>
      </div>

      <button className="btn" onClick={next}>
        Next
      </button>
    </div>
  );
}
