const Location = require("../models/Location");

// GET all locations
const getLocations = async (req, res) => {
  try {
    const locations = await Location.find();
    res.status(200).json(locations);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch locations", error });
  }
};

// GET cities by country
const getCitiesByCountry = async (req, res) => {
  try {
    const { country } = req.params;
    const cities = await Location.find({ country });
    res.status(200).json(cities);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch cities", error });
  }
};

module.exports = {
  getLocations,
  getCitiesByCountry,
};
