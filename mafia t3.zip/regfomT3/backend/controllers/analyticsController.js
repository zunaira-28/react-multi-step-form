const Analytics = require("../models/Analytics");

const getAnalytics = async (req, res) => {
  try {
    const data = await Analytics
      .find()
      .populate("userId", "name email");

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch analytics", error });
  }
};

module.exports = {
  getAnalytics,
};
