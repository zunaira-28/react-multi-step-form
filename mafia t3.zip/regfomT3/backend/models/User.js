const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    age: Number,
    cityId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Location",
    },
    preferenceId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Preference",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
