const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");

const userRoutes = require("./routes/userRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const locationRoutes = require("./routes/locationRoutes");
const preferenceRoutes = require("./routes/preferenceRoutes");

dotenv.config();

const app = express();
app.use(express.json());

// MongoDB
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch((err) => console.error("❌ MongoDB error:", err));

// Routes
app.use("/api/users", userRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/locations", locationRoutes);
app.use("/api/preferences", preferenceRoutes);

// Test route
app.get("/", (req, res) => {
  res.send("Backend running 🌸");
});

app.listen(5000, () => {
  console.log("🚀 Server running on port 5000");
});
