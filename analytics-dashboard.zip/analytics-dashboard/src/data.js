import { faker } from "@faker-js/faker";

export function generateUsers(count = 50) {
  return Array.from({ length: count }).map(() => ({
    id: faker.number.int(),
    name: faker.person.firstName(),
    gender: faker.person.sex().toLowerCase(),
    country: faker.location.country(),
    age: faker.number.int({ min: 18, max: 60 }),

    engagement: {
      likes: faker.number.int({ min: 1, max: 100 }),
      comments: faker.number.int({ min: 1, max: 50 }),
      posts: faker.number.int({ min: 1, max: 20 }),
    },

    preferences: faker.helpers.arrayElements(
      ["Sports", "Movies", "Tech", "Music", "Travel", "Food"],
      faker.number.int({ min: 1, max: 3 })
    )
  }));
}

