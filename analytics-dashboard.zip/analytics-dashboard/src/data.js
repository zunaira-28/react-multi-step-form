// ------------------------
// IMPORTS AT TOP
// ------------------------
import { faker } from "@faker-js/faker";

// ------------------------
// SALES DATA
// ------------------------
export const rawData = [
  { month: "Jan", sales: 120, revenue: 300, users: 40 },
  { month: "Feb", sales: 140, revenue: 350, users: 60 },
  { month: "Mar", sales: 200, revenue: 420, users: 80 },
  { month: "Apr", sales: 180, revenue: 400, users: 90 },
  { month: "May", sales: 220, revenue: 500, users: 120 },
  { month: "Jun", sales: 160, revenue: 310, users: 70 },
  { month: "Jul", sales: 250, revenue: 600, users: 150 },
  { month: "Aug", sales: 270, revenue: 650, users: 170 },
  { month: "Sep", sales: 300, revenue: 720, users: 190 },
  { month: "Oct", sales: 320, revenue: 800, users: 200 },
  { month: "Nov", sales: 290, revenue: 750, users: 175 },
  { month: "Dec", sales: 340, revenue: 900, users: 220 }
];

// filter function
export function filterData(months) {
  return rawData.slice(-months);
}

// ------------------------
// BIG USERS GENERATED
// ------------------------
export const bigUsers = Array.from({ length: 200 }).map(() => ({
  name: faker.person.fullName(),
  gender: faker.person.sex(),
  country: faker.location.country()
}));
