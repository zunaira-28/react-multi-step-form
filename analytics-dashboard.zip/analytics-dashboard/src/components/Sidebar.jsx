import React from "react";

export default function Sidebar({ tab, setTab }) {
  const menuItems = ["overview", "reports", "users", "settings"];

  return (
    <aside className="sidebar">
      <div className="sidebar-title">Dashboard</div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <div
            key={item}
            className={`nav-item ${tab === item ? "active" : ""}`}
            onClick={() => setTab(item)}
          >
            {item.charAt(0).toUpperCase() + item.slice(1)}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        Built with React<br />
        Chart.js for charts
      </div>
    </aside>
  );
}
