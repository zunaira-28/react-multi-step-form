import React, { useState } from "react";

function Sidebar() {
  const [active, setActive] = useState("Dashboard");

  const handleClick = (page) => {
    setActive(page);
    alert(page + " page opened!");
  };

  return (
    <div className="sidebar">
      <h2>Analytics</h2>
      <ul>
        <li
          onClick={() => handleClick("Dashboard")}
          style={{ color: active === "Dashboard" ? "#fff" : "#ccc" }}
        >
          Dashboard
        </li>

        <li
          onClick={() => handleClick("Reports")}
          style={{ color: active === "Reports" ? "#fff" : "#ccc" }}
        >
          Reports
        </li>

        <li
          onClick={() => handleClick("Settings")}
          style={{ color: active === "Settings" ? "#fff" : "#ccc" }}
        >
          Settings
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;
