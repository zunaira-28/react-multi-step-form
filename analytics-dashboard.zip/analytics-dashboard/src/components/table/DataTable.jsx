import React, { useState, useMemo } from "react";

export default function DataTable({ data }) {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [gender, setGender] = useState("all");

  const filtered = useMemo(() => {
    return data
      .filter(u => gender === "all" ? true : u.gender === gender)
      .filter(u => u.name.toLowerCase().includes(search.toLowerCase()));
  }, [search, gender, data]);

  const pageSize = 8;
  const pageData = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      {/* Filters */}
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
        <input
          placeholder="Search user..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ padding: 10, borderRadius: 8, border: "1px solid #ccc" }}
        />

        <select
          value={gender}
          onChange={e => setGender(e.target.value)}
          style={{ padding: 10, borderRadius: 8 }}
        >
          <option value="all">All</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>

      {/* Table */}
      <table width="100%" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#ddd" }}>
            <th>Name</th>
            <th>Gender</th>
            <th>Country</th>
          </tr>
        </thead>

        <tbody>
          {pageData.map((u, i) => (
            <tr key={i} style={{ borderBottom: "1px solid #eee" }}>
              <td>{u.name}</td>
              <td>{u.gender}</td>
              <td>{u.country}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination */}
      <div style={{ marginTop: 20 }}>
        <button onClick={() => setPage(Math.max(1, page - 1))}>Prev</button>
        <span style={{ padding: "0 10px" }}>Page {page}</span>
        <button onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}
