import React, { memo } from "react";
import {
  BarChart, Bar,
  LineChart, Line,
  PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, Legend, ResponsiveContainer,
} from "recharts";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#A28CF0"];

const Charts = ({ users }) => {

  const genderData = ["male", "female"].map(g => ({
  name: g,
  value: users.filter(u => u.gender.toLowerCase() === g).length,
}));


  const ageData = users.map(u => ({
    age: u.age,
    posts: u.engagement.posts,   // FIXED
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      
      {/* Gender Chart */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded shadow">
        <h2 className="text-lg font-bold mb-2 text-gray-800 dark:text-white">Gender Distribution</h2>
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={genderData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
              {genderData.map((entry, index) => (
                <Cell key={index} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Age vs Posts */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded shadow">
        <h2 className="text-lg font-bold mb-2 text-gray-800 dark:text-white">Age vs Posts</h2>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={ageData}>
            <XAxis dataKey="age" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="posts" stroke="#8884d8" />   {/* FIXED */}
          </LineChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
};

export default memo(Charts);
