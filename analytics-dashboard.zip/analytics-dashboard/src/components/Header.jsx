import React from "react";

function Header() {
  return <div className="header">Dashboard Overview</div>;
}

export default Header;
