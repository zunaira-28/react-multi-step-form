import React from "react";

export default function Header({ dark }) {
  return (
    <header className={`header ${dark ? "dark" : ""}`}>
      <div className="header-left">
        <div className="logo">AD</div>
        <div className="header-title">
          <div className="title-main">Analytics Dashboard</div>
          <div className="title-sub">Interactive visuals — React + Chart.js</div>
        </div>
      </div>
      <div className="header-right">
        <div className="welcome">Welcome, Zunaira</div>
      </div>
    </header>
  );
}
