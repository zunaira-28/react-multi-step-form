import React from "react";
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts";

const data = [
  { name: "Mon", value: 40 },
  { name: "Tue", value: 55 },
  { name: "Wed", value: 30 },
  { name: "Thu", value: 80 },
  { name: "Fri", value: 50 }
];

function CustomLineChart() {
  return (
    <div className="chart-card">
      <h3>Weekly Performance</h3>
      <LineChart width={350} height={250} data={data}>
        <Line type="monotone" dataKey="value" stroke="#4f46e5" strokeWidth={3} />
        <CartesianGrid stroke="#eee" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
      </LineChart>
    </div>
  );
}

export default CustomLineChart;
