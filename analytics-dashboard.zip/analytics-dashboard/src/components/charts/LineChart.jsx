import React from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";
import { Line } from "react-chartjs-2";

ChartJS.register(
  CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend
);

export default function LineChart({ data }) {
  const labels = data.map(d => d.month);
  const ds = {
    labels,
    datasets: [
      {
        label: "Sales",
        data: data.map(d => d.sales),
        tension: 0.3,
        fill: false,
        borderColor: "rgba(99, 102, 241, 1)", // violet
        backgroundColor: "rgba(99, 102, 241, 0.2)",
        borderWidth: 2,
      },
      {
        label: "Users",
        data: data.map(d => d.users),
        tension: 0.3,
        borderDash: [5,5],
        borderColor: "rgba(16, 185, 129, 1)", // green
        backgroundColor: "rgba(16, 185, 129, 0.2)",
        borderWidth: 2
      }
    ]
  };

  const opts = {
    responsive: true,
    plugins: {
      legend: { position: "top" },
      title: { display: false }
    },
    interaction: { mode: "index", intersect: false },
    scales: {
      y: { beginAtZero: true }
    }
  };

  return <Line options={opts} data={ds} />;
}
