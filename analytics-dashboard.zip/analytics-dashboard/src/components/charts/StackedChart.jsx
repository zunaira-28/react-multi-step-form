import React from "react";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

export default function StackedChart() {
  const data = {
    labels: ["North", "South", "East", "West"],
    datasets: [
      {
        label: "Men",
        data: [30, 40, 35, 50],
        backgroundColor: "#6366f1"
      },
      {
        label: "Women",
        data: [25, 30, 45, 35],
        backgroundColor: "#10b981"
      }
    ]
  };

  const options = {
    responsive: true,
    plugins: { legend: { position: "top" } },
    scales: { x: { stacked: true }, y: { stacked: true } }
  };

  return <Bar data={data} options={options} />;
}
