import React from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

const data = [
  { month: "Jan", user1: 30, user2: 20 },
  { month: "Feb", user1: 70, user2: 40 },
  { month: "Mar", user1: 50, user2: 60 },
  { month: "Apr", user1: 90, user2: 80 }
];

function StackedChart() {
  return (
    <div className="chart-card">
      <h3>User Growth</h3>
      <AreaChart width={350} height={250} data={data}>
        <CartesianGrid stroke="#e5e7eb" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Area type="monotone" dataKey="user1" stackId="1" fill="#3b82f6" />
        <Area type="monotone" dataKey="user2" stackId="1" fill="#8b5cf6" />
      </AreaChart>
    </div>
  );
}

export default StackedChart;
