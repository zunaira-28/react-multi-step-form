import React from "react";
import { Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

export default function PieChart() {
  const data = {
    labels: ["Male", "Female"],
    datasets: [
      {
        label: "Gender Distribution",
        data: [55, 45],
        backgroundColor: [
          "rgba(99, 102, 241, 0.7)",  // violet
          "rgba(16, 185, 129, 0.7)",  // green
        ],
        borderColor: [
          "rgba(99, 102, 241, 1)",
          "rgba(16, 185, 129, 1)",
        ],
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "right",
        labels: {
          color: "#111827", // dark text, will be overridden by dark mode via CSS if needed
        },
      },
      tooltip: {
        callbacks: {
          label: function(ctx) {
            return `${ctx.label}: ${ctx.raw}%`;
          },
        },
      },
    },
  };

  return <Pie data={data} options={options} />;
}
