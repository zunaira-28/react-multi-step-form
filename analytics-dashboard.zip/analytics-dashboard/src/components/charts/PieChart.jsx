import React from "react";
import { PieChart, Pie, Tooltip, Cell } from "recharts";

const data = [
  { name: "Chrome", value: 63 },
  { name: "Firefox", value: 20 },
  { name: "Safari", value: 10 },
  { name: "Others", value: 7 }
];

const colors = ["#6366f1", "#10b981", "#f59e0b", "#ef4444"];

function CustomPieChart() {
  return (
    <div className="chart-card">
      <h3>Browser Users</h3>
      <PieChart width={350} height={250}>
        <Pie
          data={data}
          dataKey="value"
          cx="50%"
          cy="50%"
          outerRadius={80}
          label
        >
          {data.map((e, i) => (
            <Cell key={i} fill={colors[i]} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </div>
  );
}

export default CustomPieChart;
