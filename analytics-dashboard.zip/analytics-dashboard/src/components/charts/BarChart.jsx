import React from "react";
import { BarChart, Bar, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts";

const data = [
  { name: "Jan", sales: 120 },
  { name: "Feb", sales: 200 },
  { name: "Mar", sales: 150 },
  { name: "Apr", sales: 260 }
];

function CustomBarChart() {
  return (
    <div className="chart-card">
      <h3>Monthly Sales</h3>
      <BarChart width={350} height={250} data={data}>
        <CartesianGrid stroke="#e3e3e3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="sales" fill="#10b981" />
      </BarChart>
    </div>
  );
}

export default CustomBarChart;
