import React from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function BarChart({ data }) {
  const labels = data.map(d => d.month);
  const ds = {
    labels,
    datasets: [
      {
        label: "Sales",
        data: data.map(d => d.sales),
        backgroundColor: "rgba(99, 102, 241, 0.6)", // violet
        borderColor: "rgba(99, 102, 241, 1)",
        borderWidth: 1
      },
      {
        label: "Revenue",
        data: data.map(d => d.revenue),
        backgroundColor: "rgba(16, 185, 129, 0.6)", // green
        borderColor: "rgba(16, 185, 129, 1)",
        borderWidth: 1
      }
    ]
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: "top" },
      tooltip: {
        callbacks: {
          label: ctx => `${ctx.dataset.label}: ${ctx.parsed.y}`
        }
      }
    }
  };

  return <Bar data={ds} options={options} />;
}
