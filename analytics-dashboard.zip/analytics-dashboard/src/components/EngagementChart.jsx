import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid, ResponsiveContainer } from "recharts";

export default function EngagementChart({ users }) {
  // Convert user data into chart format
  const data = users.map(u => ({
    name: u.name,
    likes: u.engagement.likes,
    comments: u.engagement.comments,
    posts: u.engagement.posts,
  }));

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-4">Engagement Overview</h2>

      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />

          <XAxis dataKey="name" />
          <YAxis />

          <Tooltip />
          <Legend />

          {/* Bars */}
          <Bar dataKey="comments" fill="#4ade80" />   {/* Green */}
          <Bar dataKey="likes" fill="#fbbf24" />      {/* Yellow */}
          <Bar dataKey="posts" fill="#60a5fa" />      {/* Blue */}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
