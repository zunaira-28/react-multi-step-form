import React from "react";

function Filters() {
  return (
    <div className="filters">
      <select>
        <option>Last 7 Days</option>
        <option>Last 30 Days</option>
        <option>This Year</option>
      </select>

      <input type="text" placeholder="Search..." />
    </div>
  );
}

export default Filters;
