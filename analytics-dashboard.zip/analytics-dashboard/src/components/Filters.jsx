import React from "react";

export default function Filters({ range, setRange }){
  const options = [3,5,7];

  return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div className="filter-buttons">
        {options.map(opt => (
          <button
            key={opt}
            onClick={() => setRange(opt)}
            className={opt===range ? "active" : ""}
          >
            Last {opt} months
          </button>
        ))}
      </div>

      <div style={{fontSize:13,color:"#374151"}}>
        <strong>Auto-refresh:</strong> off
      </div>
    </div>
  );
}
