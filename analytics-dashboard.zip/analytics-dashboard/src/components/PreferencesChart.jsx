import React from "react";
import { PieChart, Pie, Tooltip, Cell, ResponsiveContainer } from "recharts";

export default function PreferencesChart({ users }) {
  const all = users.flatMap(u => u.preferences);

  const counts = [...new Set(all)].map(pref => ({
    name: pref,
    value: all.filter(p => p === pref).length
  }));

  const colors = ["#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#d84f4f"];

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-lg font-bold mb-2">Preferences Distribution</h2>

      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie data={counts} dataKey="value" nameKey="name" outerRadius={120}>
            {counts.map((_, i) => (
              <Cell key={i} fill={colors[i % colors.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
