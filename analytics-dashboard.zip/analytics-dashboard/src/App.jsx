import React, { useState, useEffect } from "react";
import { generateUsers } from "./data";
import Charts from "./components/Charts";
import EngagementChart from "./components/EngagementChart";
import PreferencesChart from "./components/PreferencesChart";

function App() {
  const [theme, setTheme] = useState("light");
  const [activeTab, setActiveTab] = useState("demographics");
  const [users] = useState(generateUsers(100));

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  return (
    <div className="min-h-screen p-6 bg-white text-black dark:bg-gray-900 dark:text-white">

      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
        <button
          className="px-4 py-2 rounded bg-blue-600 text-white"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          Toggle {theme === "dark" ? "Light" : "Dark"}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        {["demographics", "engagement", "preferences"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded ${
              activeTab === tab
                ? "bg-blue-600 text-white"
                : "bg-gray-200 dark:bg-gray-700 dark:text-white"
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "demographics" && <Charts users={users} />}
      {activeTab === "engagement" && <EngagementChart users={users} />}
      {activeTab === "preferences" && <PreferencesChart users={users} />}

    </div>
  );
}

export default App;
