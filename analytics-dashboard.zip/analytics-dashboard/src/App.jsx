import React, { Suspense } from "react";
import "./App.css";

// Components
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Filters from "./components/Filters";
import LineChart from "./components/charts/LineChart";
import BarChart from "./components/charts/BarChart";

// Lazy Loaded Charts
const PieChart = React.lazy(() => import("./components/charts/PieChart"));
const StackedChart = React.lazy(() => import("./components/charts/StackedChart"));

function App() {
  return (
    <div className="dashboard-container">

      {/* Sidebar */}
      <Sidebar />

      <div className="main-content">
        
        {/* Header */}
        <Header />

        {/* Filters */}
        <Filters />

        {/* Charts Grid */}
        <div className="charts-grid">
          <LineChart />
          <BarChart />

          <Suspense fallback={<div className="loader">Loading Charts...</div>}>
            <PieChart />
            <StackedChart />
          </Suspense>
        </div>

      </div>
    </div>
  );
}

export default App;
