import React, { useState, Suspense } from "react";

// Components
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Filters from "./components/Filters";
import LineChart from "./components/charts/LineChart";
import BarChart from "./components/charts/BarChart";
import "./App.css";

// Lazy-loaded components
const PieChart = React.lazy(() => import("./components/charts/PieChart"));
const StackedChart = React.lazy(() => import("./components/charts/StackedChart"));
const DataTable = React.lazy(() => import("./components/table/DataTable"));

// Data
import { filterData, bigUsers } from "./data";

export default function App() {
  const [range, setRange] = useState(7);
  const [tab, setTab] = useState("overview");
  const [dark, setDark] = useState(false);

  const filtered = filterData(range);

  return (
    <div className={`app-root ${dark ? "dark" : ""}`}>
      {/* Pass tab and setTab to Sidebar */}
      <Sidebar tab={tab} setTab={setTab} />

      <div className="main">
        <Header />

        {/* Dark/Light Mode Toggle */}
        <div className="mode-toggle">
          <button onClick={() => setDark(!dark)}>
            {dark ? "Light Mode" : "Dark Mode"}
          </button>
        </div>

        {/* Filters */}
        <div className="controls">
          <Filters range={range} setRange={setRange} />
        </div>

        {/* Dashboard Content */}
        <Suspense fallback={<div>Loading…</div>}>
          {tab === "overview" && (
            <div className="dashboard-grid">
              <div className="card">
                <h3>Sales Over Time</h3>
                <LineChart data={filtered} />
              </div>

              <div className="card">
                <h3>Sales vs Revenue</h3>
                <BarChart data={filtered} />
              </div>

              <div className="card">
                <h3>Gender (Pie)</h3>
                <PieChart data={filtered} />
              </div>

              <div className="card wide">
                <h3>Users by Region</h3>
                <StackedChart data={filtered} />
              </div>
            </div>
          )}

          {(tab === "reports" || tab === "users") && (
            <div className="card wide">
              <h3>{tab.charAt(0).toUpperCase() + tab.slice(1)} Data Table</h3>
              <DataTable data={bigUsers} />
            </div>
          )}

          {tab === "settings" && (
            <div className="card">
              <h3>Settings Coming Soon…</h3>
            </div>
          )}
        </Suspense>
      </div>
    </div>
  );
}
