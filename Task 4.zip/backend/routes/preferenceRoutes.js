const express = require("express");
const { getPreferences } = require("../controllers/preferenceController");

const router = express.Router();

// GET all preferences
router.get("/", getPreferences);

module.exports = router;
