const mongoose = require("mongoose");
const { faker } = require("@faker-js/faker");

const User = require("../models/User");
const Location = require("../models/Location");
const Preference = require("../models/Preference");
const Analytics = require("../models/Analytics");

require("dotenv").config();

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected for seeding"))
  .catch((err) => console.error(err));

const seedDB = async () => {
  try {
    await User.deleteMany();
    await Location.deleteMany();
    await Preference.deleteMany();
    await Analytics.deleteMany();

    // Locations
    const locations = [];
    for (let i = 0; i < 5; i++) {
      const loc = await Location.create({
        country: "Pakistan",
        city: faker.location.city(),
      });
      locations.push(loc);
    }

    // Users + Preferences + Analytics
    for (let i = 0; i < 30; i++) {
      const pref = await Preference.create({
        theme: faker.helpers.arrayElement(["light", "dark"]),
        language: faker.helpers.arrayElement(["en", "ur"]),
        notifications: faker.datatype.boolean(),
      });

      const user = await User.create({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        age: faker.number.int({ min: 18, max: 55 }),
        cityId: faker.helpers.arrayElement(locations)._id,
        preferenceId: pref._id,
      });

      await Analytics.create({
        userId: user._id,
        action: faker.helpers.arrayElement(["login", "search", "view"]),
        device: faker.helpers.arrayElement(["mobile", "desktop"]),
        timestamp: faker.date.recent(),
      });
    }

    console.log("🌱 Database seeded successfully!");
    process.exit();
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
};

seedDB();
