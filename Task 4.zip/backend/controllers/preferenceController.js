const Preference = require("../models/Preference");

// GET all preferences
const getPreferences = async (req, res) => {
  try {
    const preferences = await Preference.find();
    res.status(200).json(preferences);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch preferences", error });
  }
};

module.exports = {
  getPreferences,
};
