const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  preferences: { type: mongoose.Schema.Types.ObjectId, ref: 'Preference' },
  location: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
