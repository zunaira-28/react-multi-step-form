const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  loginCount: Number,
  lastLogin: Date,
  actions: [String],
});

module.exports = mongoose.model('Analytics', analyticsSchema);
