const mongoose = require('mongoose');

const preferenceSchema = new mongoose.Schema({
  theme: String,
  notifications: Boolean,
  language: String,
});

module.exports = mongoose.model('Preference', preferenceSchema);
