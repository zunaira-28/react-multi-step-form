// seed.js
const mongoose = require('./db'); // db.js se MongoDB connect
const { faker } = require('@faker-js/faker');

const User = require('./models/User');
const Preference = require('./models/Preference');
const Location = require('./models/Location');
const Analytics = require('./models/Analytics');

async function seedDatabase() {
  try {
    // Purane data clear karo
    await User.deleteMany({});
    await Preference.deleteMany({});
    await Location.deleteMany({});
    await Analytics.deleteMany({});
    console.log('Old data cleared.');

    // Location create karo
    const location = new Location({
      country: 'Pakistan',
      cities: ['Karachi', 'Lahore', 'Islamabad', 'Multan', 'Peshawar']
    });
    await location.save();

    // Users + Preferences + Analytics
    for (let i = 0; i < 10; i++) {
      const pref = new Preference({
        theme: faker.helpers.arrayElement(['dark','light']),
        notifications: faker.datatype.boolean(),
        language: faker.helpers.arrayElement(['English','Urdu'])
      });
      await pref.save();

      const user = new User({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        password: faker.internet.password(),
        preferences: pref._id,
        location: location._id
      });
      await user.save();

      const analytic = new Analytics({
        userId: user._id,
        loginCount: faker.number.int({ min: 1, max: 50 }),
        lastLogin: faker.date.recent(),
        actions: [
          faker.hacker.verb(),
          faker.hacker.noun(),
          faker.hacker.ingverb()
        ]
      });
      await analytic.save();
    }

    console.log('Database seeding completed!');
  } catch (err) {
    console.error('Error seeding database:', err);
  } finally {
    mongoose.disconnect();
  }
}

seedDatabase();
