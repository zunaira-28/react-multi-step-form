import { PieChart, Pie, Tooltip } from "recharts";

export default function ChartsDonut({ users }) {
  const data = [
    { name: "Reading", value: users.filter(u => u.hobby === "Reading").length },
    { name: "Gaming", value: users.filter(u => u.hobby === "Gaming").length },
    { name: "Travel", value: users.filter(u => u.hobby === "Travel").length },
  ];

  return (
    <div className="chartCard">
      <h3>Hobbies (Donut)</h3>
      <PieChart width={350} height={250}>
        <Pie data={data} cx={170} cy={120} innerRadius={50} outerRadius={90} dataKey="value" fill="#ff9ecd" />
        <Tooltip />
      </PieChart>
    </div>
  );
}
