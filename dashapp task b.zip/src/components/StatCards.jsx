export default function StatCards({ users }) {
  return (
    <div className="stats">
      <div className="card">👤 Total Users: {users.length}</div>
      <div className="card">🌸 Females: {users.filter(u => u.gender === "Female").length}</div>
      <div className="card">🎮 Hobby: Gaming {users.filter(u => u.hobby === "Gaming").length}</div>
    </div>
  );
}
