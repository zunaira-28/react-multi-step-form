import { BarChart, Bar, XAxis, Tooltip } from "recharts";

export default function ChartsStacked({ users }) {
  const data = [
    {
      name: "Group A",
      male: users.filter(u => u.gender === "Male").length,
      female: users.filter(u => u.gender === "Female").length,
    }
  ];

  return (
    <div className="chartCard">
      <h3>Gender Comparison (Stacked)</h3>
      <BarChart width={400} height={250} data={data}>
        <XAxis dataKey="name" />
        <Tooltip />
        <Bar dataKey="male" stackId="a" fill="#97d5ff" />
        <Bar dataKey="female" stackId="a" fill="#ffadd6" />
      </BarChart>
    </div>
  );
}
