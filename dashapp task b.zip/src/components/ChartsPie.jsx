import { PieChart, Pie, Tooltip } from "recharts";

const ChartsPie = ({ users }) => {
  const data = [
    { name: "Male", value: users.filter(u => u.gender === "Male").length },
    { name: "Female", value: users.filter(u => u.gender === "Female").length },
    { name: "Other", value: users.filter(u => u.gender === "Other").length },
  ];

  return (
    <div className="chartCard">
      <h3>Gender Split (Pie)</h3>
      <PieChart width={350} height={250}>
        <Pie data={data} cx={170} cy={120} outerRadius={90} dataKey="value" fill="#ffb3c6" />
        <Tooltip />
      </PieChart>
    </div>
  );
};

export default ChartsPie;
