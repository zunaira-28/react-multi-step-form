import React, { useState, memo, useMemo } from "react";
import "./DataTable.css";

// Memoized TableRow
const TableRow = memo(({ user, index }) => (
  <tr className="tableRow" style={{ animationDelay: `${index * 0.05}s` }}>
    <td>{user.name}</td>
    <td>{user.email}</td>
    <td>{user.gender}</td>
    <td>{user.country}</td>
  </tr>
));

function DataTableComponent({ users, darkMode }) {
  const [search, setSearch] = useState("");

  // Memoize filtered users
  const filtered = useMemo(() => {
    return users.filter(
      u =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.country.toLowerCase().includes(search.toLowerCase())
    );
  }, [users, search]);

  const exportCSV = () => {
    const rows = [
      ["Name", "Email", "Gender", "Country"],
      ...filtered.map(u => [u.name, u.email, u.gender, u.country])
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "users.csv";
    link.click();
  };

  return (
    <div className={`tableBox animateTable ${darkMode ? "dark" : ""}`}>
      <h3 className="tableTitle">User Table</h3>

      <input
        className="searchInput"
        placeholder="Search name or country…"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      <button className="csvBtn" onClick={exportCSV}>
        Export CSV
      </button>

      <table className="cuteTable">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Country</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((u, index) => (
            <TableRow key={u.id} user={u} index={index} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Memoize DataTable
export default memo(DataTableComponent);
