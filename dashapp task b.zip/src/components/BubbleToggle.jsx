import React, { useState } from "react";
import "./BubbleToggle.css";

export default function BubbleToggle({ darkMode, setDarkMode }) {
  const [bounce, setBounce] = useState(false);

  const toggle = () => {
    setBounce(true);
    setDarkMode(!darkMode);

    setTimeout(() => setBounce(false), 400); // remove bounce after animation
  };

  return (
    <div 
      className={`bubble-toggle ${bounce ? "bounce" : ""} ${
        darkMode ? "bubble-dark" : "bubble-light"
      }`}
      onClick={toggle}
    >
      {/* Sliding Sun/Moon */}
      <div
        className={`slider ${darkMode ? "slide-right" : "slide-left"}`}
      >
        {darkMode ? (
          <span className="moon">🌙</span>
        ) : (
          <span className="sun">☀️</span>
        )}
      </div>

      {/* sparkles */}
      {!darkMode && <div className="sparkle sparkle1">✨</div>}
      {!darkMode && <div className="sparkle sparkle2">✦</div>}
      {darkMode && <div className="sparkle sparkle3">✧</div>}
    </div>
  );
}
