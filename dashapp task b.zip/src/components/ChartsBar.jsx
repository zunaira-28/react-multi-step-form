import { BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";

export default function ChartsBar({ users }) {
  const data = [
    { name: "18-25", count: users.filter(u => u.age <= 25).length },
    { name: "26-40", count: users.filter(u => u.age > 25 && u.age <= 40).length },
    { name: "40+", count: users.filter(u => u.age > 40).length },
  ];

  return (
    <div className="chartCard">
      <h3>Age Distribution (Bar)</h3>
      <BarChart width={400} height={250} data={data}>
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="count" fill="#f7a8d8" />
      </BarChart>
    </div>
  );
}
