export default function Tabs({ tab, setTab }) {
  return (
    <div className="tabs">
      <button className={tab === "demographics" ? "active" : ""} onClick={() => setTab("demographics")}>Demographics</button>
      <button className={tab === "engagement" ? "active" : ""} onClick={() => setTab("engagement")}>Engagement</button>
      <button className={tab === "preferences" ? "active" : ""} onClick={() => setTab("preferences")}>Preferences</button>
    </div>
  );
}
