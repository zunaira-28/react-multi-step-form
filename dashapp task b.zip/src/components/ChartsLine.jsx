import { LineChart, Line, XAxis, Tooltip } from "recharts";

export default function ChartsLine({ users }) {
  const data = users.slice(0, 20).map((u, i) => ({
    index: i,
    age: u.age,
  }));

  return (
    <div className="chartCard">
      <h3>Random Age Trend (Line)</h3>
      <LineChart width={400} height={250} data={data}>
        <XAxis dataKey="index" />
        <Tooltip />
        <Line type="monotone" dataKey="age" stroke="#ff80c0" />
      </LineChart>
    </div>
  );
}
