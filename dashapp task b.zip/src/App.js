import React, { useState, useEffect, Suspense, lazy } from "react";
import Dashboard from "./pages/Dashboard";
import BubbleToggle from "./components/BubbleToggle";

import "./styles/dashboard.css";
import "./components/BubbleToggle.css";

import users from "./data/users";

// Lazy load DataTable
const DataTable = lazy(() => import("./components/DataTable"));

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [tab] = useState("dashboard"); // <-- tab state

  useEffect(() => {
    document.body.classList.toggle("dark", darkMode);
  }, [darkMode]);

  return (
    <div
      className={`min-h-screen transition-all duration-700 
      ${darkMode ? "bg-[#0f0f1a] text-white" : "bg-pink-50 text-gray-800"}
      `}
    >
      {/* Bubble Toggle */}
      <div className="w-full flex justify-end p-4 pr-6">
        <BubbleToggle darkMode={darkMode} setDarkMode={setDarkMode} />
      </div>

     

      {/* 🌈 Dashboard Content */}
      {tab === "dashboard" && <Dashboard darkMode={darkMode} />}

      {/* 📊 Preferences (Lazy Load DataTable) */}
      {tab === "preferences" && (
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-4">
            Pakistani Users Table
          </h2>

          <Suspense fallback={<div>Loading table...</div>}>
            <DataTable users={users} darkMode={darkMode} />
          </Suspense>
        </div>
      )}
    </div>
  );
}
