import React from "react";
import DataTable from "../components/DataTable";

export default function Preferences({ users, darkMode }) {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-3">User Preferences</h2>

      <DataTable users={users} darkMode={darkMode} />
    </div>
  );
}
