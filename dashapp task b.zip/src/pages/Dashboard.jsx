import users from "../data/users";
import { useState, useEffect, Suspense, lazy, memo } from "react";

// Memoized chart and UI components
import TabsComponent from "../components/Tabs";
import StatCardsComponent from "../components/StatCards";
import ChartsBarComponent from "../components/ChartsBar";
import ChartsLineComponent from "../components/ChartsLine";
import ChartsPieComponent from "../components/ChartsPie";
import ChartsDonutComponent from "../components/ChartsDonut";
import ChartsStackedComponent from "../components/ChartsStacked";

// Lazy load DataTable
const DataTable = lazy(() => import("../components/DataTable"));

// Memoized children
const Tabs = memo(TabsComponent);
const StatCards = memo(StatCardsComponent);
const ChartsBar = memo(ChartsBarComponent);
const ChartsLine = memo(ChartsLineComponent);
const ChartsPie = memo(ChartsPieComponent);
const ChartsDonut = memo(ChartsDonutComponent);
const ChartsStacked = memo(ChartsStackedComponent);

function DashboardComponent({ darkMode }) {
  const [tab, setTab] = useState("demographics");

  // fade animation
  const [fade, setFade] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setFade(true), 50);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className={`dash-container transition-all duration-700 p-6
        ${fade ? "fade-in" : "opacity-0"}
        ${darkMode ? "bg-[#12121c] text-white" : "bg-pink-50 text-gray-800"}
      `}
    >
      <h1 className="title text-3xl font-bold mb-6 text-center">
        Analytics Dashboard & Interactive Visuals
      </h1>

      {/* Tabs */}
      <Tabs tab={tab} setTab={setTab} darkMode={darkMode} />

      {/* Stat Cards */}
      <StatCards users={users} darkMode={darkMode} />

      {/* Charts */}
      {tab === "demographics" && (
        <>
          <ChartsPie users={users} darkMode={darkMode} />
          <ChartsDonut users={users} darkMode={darkMode} />
          <ChartsBar users={users} darkMode={darkMode} />
        </>
      )}
      {tab === "engagement" && (
        <>
          <ChartsLine users={users} darkMode={darkMode} />
          <ChartsStacked users={users} darkMode={darkMode} />
        </>
      )}

      {/* Lazy loaded DataTable */}
      {tab === "preferences" && (
        <Suspense fallback={<div className="text-center mt-10">Loading Table...</div>}>
          <DataTable users={users} darkMode={darkMode} />
        </Suspense>
      )}
    </div>
  );
}

// Memoized Dashboard
export default memo(DashboardComponent);
