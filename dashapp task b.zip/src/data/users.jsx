// src/data/users.js
import { faker } from "@faker-js/faker";

const pakistaniNames = [
  { name: "Ahmed", gender: "Male" },
  { name: "Ali", gender: "Male" },
  { name: "Hassan", gender: "Male" },
  { name: "Ayesha", gender: "Female" },
  { name: "Fatima", gender: "Female" },
];
const pakistaniLastNames = ["Khan", "Ali", "Malik", "Shah"];

const ukNames = [
  { name: "James", gender: "Male" },
  { name: "Oliver", gender: "Male" },
  { name: "Emily", gender: "Female" },
  { name: "Sophia", gender: "Female" },
  { name: "Harry", gender: "Male" },
];
const ukLastNames = ["Smith", "Brown", "Taylor", "Wilson"];

const londonNames = [
  { name: "Liam", gender: "Male" },
  { name: "Noah", gender: "Male" },
  { name: "Chloe", gender: "Female" },
  { name: "Ella", gender: "Female" },
  { name: "Jack", gender: "Male" },
];
const londonLastNames = ["Johnson", "Roberts", "Walker", "Hall"];

const saudiNames = [
  { name: "Mohammed", gender: "Male" },
  { name: "Abdullah", gender: "Male" },
  { name: "Sara", gender: "Female" },
  { name: "Noura", gender: "Female" },
  { name: "Faisal", gender: "Male" },
];
const saudiLastNames = ["Al Saud", "Al-Faisal", "Al-Harbi", "Al-Qahtani"];

const brazilNames = [
  { name: "Lucas", gender: "Male" },
  { name: "Mateus", gender: "Male" },
  { name: "Ana", gender: "Female" },
  { name: "Beatriz", gender: "Female" },
  { name: "Gabriel", gender: "Male" },
];
const brazilLastNames = ["Silva", "Santos", "Oliveira", "Costa"];

const malaysiaNames = [
  { name: "Ahmad", gender: "Male" },
  { name: "Hafiz", gender: "Male" },
  { name: "Aina", gender: "Female" },
  { name: "Nur", gender: "Female" },
  { name: "Wei", gender: "Male" },
];
const malaysiaLastNames = ["Tan", "Lee", "Abdullah", "Lim"];

// Country-specific email domains
const emailDomains = {
  "Pakistan": ["gmail.com", "hotmail.com"],
  "UK": ["hotmail.co.uk", "gmail.com"],
  "London": ["gmail.com", "yahoo.co.uk"],
  "Saudi Arabia": ["yahoo.com.sa", "gmail.com"],
  "Brazil": ["hotmail.com.br", "gmail.com"],
  "Malaysia": ["gmail.com", "yahoo.com.my"],
};

function generateUsers(country, firstNames, lastNames, count = 50) {
  return Array.from({ length: count }).map(() => {
    const first = faker.helpers.arrayElement(firstNames);
    const lastName = faker.helpers.arrayElement(lastNames);
    const gender = Math.random() < 0.05 ? "Other" : first.gender;
    const domain = faker.helpers.arrayElement(emailDomains[country]);

    return {
      id: faker.string.uuid(),
      name: `${first.name} ${lastName}`,
      email: `${first.name.toLowerCase()}.${lastName.toLowerCase()}@${domain}`,
      age: faker.number.int({ min: 18, max: 60 }),
      gender,
      country,
      hobby: faker.helpers.arrayElement(["Reading", "Gaming", "Travel", "Music"]),
    };
  });
}

const users = [
  ...generateUsers("Pakistan", pakistaniNames, pakistaniLastNames),
  ...generateUsers("UK", ukNames, ukLastNames),
  ...generateUsers("London", londonNames, londonLastNames),
  ...generateUsers("Saudi Arabia", saudiNames, saudiLastNames),
  ...generateUsers("Brazil", brazilNames, brazilLastNames),
  ...generateUsers("Malaysia", malaysiaNames, malaysiaLastNames),
];

export default users;
