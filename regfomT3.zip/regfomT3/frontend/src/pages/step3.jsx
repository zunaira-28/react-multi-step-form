import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Step3({ form, setForm, setStep }) {
  const nav = useNavigate();
  const [error, setError] = useState("");
  const [showPass, setShowPass] = useState(false);

  const next = () => {
    if (!form.username || !form.password || !form.confirmPassword) {
      setError("Please fill all required fields");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setError("");
    setStep(4);
    nav("/step4");
  };

  const back = () => {
    setStep(2);
    nav("/step2");
  };

  return (
    <div className="card fade-slide">
      <h2> Step 3: Account Credentials</h2>
      {error && <p className="error">{error}</p>}

      <div className="box">
        <label>Username*</label>
        <input value={form.username} onChange={e => setForm({...form, username: e.target.value})} />
      </div>
      <div className="box">
        <label>Password*</label>
        <input type={showPass ? "text" : "password"} value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
      </div>
      <div className="box">
        <label>Confirm Password*</label>
        <input type={showPass ? "text" : "password"} value={form.confirmPassword} onChange={e => setForm({...form, confirmPassword: e.target.value})} />
      </div>
      <div className="box">
        <label>
          <input type="checkbox" checked={showPass} onChange={() => setShowPass(!showPass)} /> Show Password
        </label>
      </div>

      <div className="btns">
        <button className="btn back" onClick={back}>Back</button>
        <button className="btn" onClick={next}>Next</button>
      </div>
    </div>
  );
}
