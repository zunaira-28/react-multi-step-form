const express = require("express");
const auth = require("../middleware/authMiddleware");

const router = express.Router();

let profiles = [];

// Create / Save profile
router.post("/", auth, (req, res) => {
  profiles.push({ ...req.body, userId: req.user.id });
  res.json({ msg: "Profile saved" });
});

// Read profile
router.get("/:id", auth, (req, res) => {
  const profile = profiles.find(p => p.userId == req.params.id);
  res.json(profile);
});

// Update profile
router.put("/:id", auth, (req, res) => {
  profiles = profiles.map(p =>
    p.userId == req.params.id ? { ...req.body, userId: req.user.id } : p
  );
  res.json({ msg: "Profile updated" });
});

// Delete profile
router.delete("/:id", auth, (req, res) => {
  profiles = profiles.filter(p => p.userId != req.params.id);
  res.json({ msg: "Profile deleted" });
});

module.exports = router;
