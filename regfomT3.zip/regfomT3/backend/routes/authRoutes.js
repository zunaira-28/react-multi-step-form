const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();

// In-memory users array
let users = [];

// POST /api/auth/register
router.post("/register", (req, res) => {
  const { name, email, age, gender, country, city, username, hobbies, otherHobby, newsletter } = req.body;

  // Validate required fields
  if (!name || !email || !age || !gender) {
    return res.status(400).json({ message: "All fields are required" });
  }

  // Create user object
  const user = {
    id: Date.now(), // simple unique id
    name,
    email,
    age,
    gender,
    country,
    city,
    username,
    hobbies: hobbies || [],
    otherHobby: otherHobby || "",
    newsletter: newsletter || false
  };

  // Save user in memory
  users.push(user);

  // Generate JWT
  const token = jwt.sign(
    { id: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: "1h" }
  );

  // Send response with token and message
  res.status(201).json({
    message: "Registration successful",
    token
  });
});

module.exports = router;
