import React from "react";
import "../App.css";

const ProgressBar = ({ step }) => {
  const width = (step / 3) * 100 + "%";

  return (
    <div className="progress-container">
      <div className="progress-bar" style={{ width }}></div>
    </div>
  );
};

export default ProgressBar;






