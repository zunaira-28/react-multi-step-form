import React, { createContext, useState, useEffect } from "react";

export const FormContext = createContext();

export const FormProvider = ({ children }) => {
  const [data, setData] = useState(() => {
    return JSON.parse(localStorage.getItem("formData")) || {
      name: "",
      email: "",
      country: "",
      city: "",
      gender: "",
      interests: []
    };
  });

  useEffect(() => {
    localStorage.setItem("formData", JSON.stringify(data));
  }, [data]);

  return (
    <FormContext.Provider value={{ data, setData }}>
      {children}
    </FormContext.Provider>
  );
};

