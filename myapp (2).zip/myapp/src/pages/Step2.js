import "../App.css";
import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { FormContext } from "../context/FormContext";
import ProgressBar from "../components/ProgressBar";

const cities = {
  Pakistan: ["Karachi", "Lahore", "Islamabad"],
  India: ["Delhi", "Mumbai", "Kolkata"],
  USA: ["New York", "Chicago", "Los Angeles"],
};

export default function Step2() {
  const { data, setData } = useContext(FormContext);
  const navigate = useNavigate();

  return (
    <div className="container">
      <ProgressBar step={2} />

      <h2>Location Info</h2>

      <select
        value={data.country}
        onChange={(e) =>
          setData({ ...data, country: e.target.value, city: "" })
        }
      >
        <option value="">Select Country</option>
        {Object.keys(cities).map((country) => (
          <option>{country}</option>
        ))}
      </select>

      <select
        value={data.city}
        onChange={(e) => setData({ ...data, city: e.target.value })}
      >
        <option value="">Select City</option>
        {data.country &&
          cities[data.country].map((city) => <option>{city}</option>)}
      </select>

      <button onClick={() => navigate("/")}>← Back</button>
      <button onClick={() => navigate("/step3")}>Next →</button>
    </div>
  );
}
