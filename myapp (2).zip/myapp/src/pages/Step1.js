import "../App.css";

import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FormContext } from "../context/FormContext";
import ProgressBar from "../components/ProgressBar";

export default function Step1() {
  const { data, setData } = useContext(FormContext);
  const navigate = useNavigate();

  const [error, setError] = useState("");

  const next = () => {
    if (!data.name || !data.email) {
      setError("Name & Email required!");
      return;
    }

    // Email Regex
    const emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(data.email)) {
      setError("Invalid Email Format!");
      return;
    }

    navigate("/step2");
  };

  return (
    <div className="container">
      <ProgressBar step={1} />

      <h2>Personal Info</h2>

      <input
        type="text"
        placeholder="Full Name"
        value={data.name}
        onChange={(e) => setData({ ...data, name: e.target.value })}
      />

      <input
        type="email"
        placeholder="Email Address"
        value={data.email}
        onChange={(e) => setData({ ...data, email: e.target.value })}
      />

      {error && <p style={{ color: "red" }}>{error}</p>}

      <button onClick={next}>Next →</button>
    </div>
  );
}
