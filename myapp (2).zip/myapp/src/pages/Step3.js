import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { FormContext } from "../context/FormContext";
import ProgressBar from "../components/ProgressBar";

export default function Step3() {
  const { data, setData } = useContext(FormContext);
  const navigate = useNavigate();

  const toggleInterest = (value) => {
    let updated = [...data.interests];
    if (updated.includes(value)) {
      updated = updated.filter((i) => i !== value);
    } else {
      updated.push(value);
    }
    setData({ ...data, interests: updated });
  };

  return (
    <div className="container">
      <ProgressBar step={3} />

      <h2>Your Preferences</h2>

      <label>
        <input
          type="checkbox"
          checked={data.interests.includes("Coding")}
          onChange={() => toggleInterest("Coding")}
        />
        Coding
      </label>

      <label>
        <input
          type="checkbox"
          checked={data.interests.includes("Design")}
          onChange={() => toggleInterest("Design")}
        />
        Design
      </label>

      <label>
        <input
          type="checkbox"
          checked={data.interests.includes("Gaming")}
          onChange={() => toggleInterest("Gaming")}
        />
        Gaming
      </label>

      <button onClick={() => navigate("/step2")}>← Back</button>
      <button onClick={() => navigate("/summary")}>Submit</button>
    </div>
  );
}
