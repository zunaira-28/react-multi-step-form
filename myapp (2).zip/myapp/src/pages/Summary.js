import "../App.css";
import React, { useContext } from "react";
import { FormContext } from "../context/FormContext";
import { useNavigate } from "react-router-dom";

export default function Summary() {
  const { data } = useContext(FormContext);
  const navigate = useNavigate();

  return (
    <div className="container">
      <h2>Profile Summary</h2>

      <p><strong>Name:</strong> {data.name}</p>
      <p><strong>Email:</strong> {data.email}</p>
      <p><strong>Country:</strong> {data.country}</p>
      <p><strong>City:</strong> {data.city}</p>
      <p><strong>Interests:</strong> {data.interests.join(", ")}</p>

      <button onClick={() => navigate("/")}>Edit Info</button>
    </div>
  );
}
