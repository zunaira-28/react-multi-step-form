 import React from 'react';
import { useNavigate } from 'react-router-dom';

function Step3({ formData }) {
  const navigate = useNavigate();

  return (
    <div className="form-container">
      <h2>Step 3: Review</h2>
      <p><b>Name:</b> {formData.name}</p>
      <p><b>Email:</b> {formData.email}</p>
      <p><b>Country:</b> {formData.country}</p>
      <p><b>City:</b> {formData.city}</p>
      <p><b>Preferences:</b> {formData.preferences}</p>

      <button onClick={() => navigate('/step2')}>Edit</button>
      <button onClick={() => navigate('/summary')}>Submit</button>
    </div>
  );
}

export default Step3;