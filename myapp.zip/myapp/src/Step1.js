import React from "react";
import { useNavigate } from "react-router-dom";

export default function Step1({ formData, setFormData }) {
  const navigate = useNavigate();

  const countries = ["Pakistan", "India", "America"];
  const provinces = ["Punjab", "Sindh", "KPK", "Balochistan"];
  const cities = ["Lahore", "Karachi", "Islamabad", "Quetta", "Peshawar"];

  return (
    <div style={{ width: "70%", margin: "auto" }}>
      <h2>Owner Information</h2>

      <div style={{ display: "flex", gap: "10px" }}>
        <input
          style={{ flex: 1 }}
          placeholder="First Name"
          value={formData.firstName}
          onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
        />
        <input
          style={{ flex: 1 }}
          placeholder="Last Name"
          value={formData.lastName}
          onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
        />
      </div>

      <br />

      <div style={{ display: "flex", gap: "10px" }}>
        <select
          style={{ flex: 1 }}
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
        >
          <option>Please Select</option>
          <option>Mr</option>
          <option>Miss</option>
          <option>Mrs</option>
        </select>

        <input
          style={{ flex: 1 }}
          placeholder="Company Name"
          value={formData.companyName}
          onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
        />
      </div>

      <br />

      <select
        style={{ width: "100%" }}
        value={formData.country}
        onChange={(e) => setFormData({ ...formData, country: e.target.value })}
      >
        <option>Select Country</option>
        {countries.map((c) => (
          <option key={c}>{c}</option>
        ))}
      </select>

      <br /><br />

      <select
        style={{ width: "100%" }}
        value={formData.province}
        onChange={(e) => setFormData({ ...formData, province: e.target.value })}
      >
        <option>Select Province</option>
        {provinces.map((p) => (
          <option key={p}>{p}</option>
        ))}
      </select>

      <br /><br />

      <select
        style={{ width: "100%" }}
        value={formData.city}
        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
      >
        <option>Select City</option>
        {cities.map((c) => (
          <option key={c}>{c}</option>
        ))}
      </select>

      <br /><br />

      <input
        style={{ width: "100%" }}
        placeholder="Postcode"
        value={formData.postcode}
        onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
      />

      <br /><br />

      <div style={{ display: "flex", gap: "10px" }}>
        <input
          style={{ flex: 1 }}
          placeholder="Home Phone Number"
          value={formData.homePhone}
          onChange={(e) => setFormData({ ...formData, homePhone: e.target.value })}
        />
        <input
          style={{ flex: 1 }}
          placeholder="Mobile Phone Number"
          value={formData.mobilePhone}
          onChange={(e) => setFormData({ ...formData, mobilePhone: e.target.value })}
        />
      </div>

      <br />

      <input
        style={{ width: "100%" }}
        placeholder="Fax Number"
        value={formData.fax}
        onChange={(e) => setFormData({ ...formData, fax: e.target.value })}
      />

      <br /><br />

      <input
        style={{ width: "100%" }}
        placeholder="Email Address"
        value={formData.email}
        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
      />

      <br /><br />

      <button onClick={() => navigate("/step2")} style={{ padding: "10px 20px" }}>
        Next
      </button>
    </div>
  );
}
