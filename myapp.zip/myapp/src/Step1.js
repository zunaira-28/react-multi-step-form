 import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Step1({ formData, setFormData }) {
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleNext = () => {
    let newErrors = {};
    if (!formData.name) newErrors.name = 'Name required';
    if (!formData.email.match(/^\S+@\S+\.\S+$/)) newErrors.email = 'Invalid email';
    if (!formData.password.match(/.{6,}/)) newErrors.password = 'Password min 6 chars';

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      navigate('/step2');
    }
  };

  return (
    <div className="form-container">
      <h2>Step 1: Basic Info</h2>
      <input
        type="text"
        placeholder="Name"
        value={formData.name}
        onChange={e => setFormData({...formData, name: e.target.value})}
      />
      {errors.name && <p className="error">{errors.name}</p>}

      <input
        type="email"
        placeholder="Email"
        value={formData.email}
        onChange={e => setFormData({...formData, email: e.target.value})}
      />
      {errors.email && <p className="error">{errors.email}</p>}

      <input
        type="password"
        placeholder="Password"
        value={formData.password}
        onChange={e => setFormData({...formData, password: e.target.value})}
      />
      {errors.password && <p className="error">{errors.password}</p>}

      <button onClick={handleNext}>Next</button>
    </div>
  );
}

export default Step1;