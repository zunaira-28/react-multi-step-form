 import React from 'react';
import { useNavigate } from 'react-router-dom';

const countryCity = {
  Pakistan: ['Karachi', 'Lahore', 'Islamabad'],
  USA: ['New York', 'Los Angeles', 'Chicago'],
  India: ['Delhi', 'Mumbai', 'Bangalore']
};

function Step2({ formData, setFormData }) {
  const navigate = useNavigate();

  return (
    <div className="form-container">
      <h2>Step 2: Preferences</h2>

      <select
        value={formData.country}
        onChange={e => setFormData({...formData, country: e.target.value, city: ''})}
      >
        <option value="">Select Country</option>
        {Object.keys(countryCity).map(c => <option key={c}>{c}</option>)}
      </select>

      <select
        value={formData.city}
        onChange={e => setFormData({...formData, city: e.target.value})}
        disabled={!formData.country}
      >
        <option value="">Select City</option>
        {formData.country && countryCity[formData.country].map(city => <option key={city}>{city}</option>)}
      </select>

      <textarea
        placeholder="Your Preferences"
        value={formData.preferences}
        onChange={e => setFormData({...formData, preferences: e.target.value})}
      ></textarea>

      <button onClick={() => navigate('/')}>Back</button>
      <button onClick={() => navigate('/step3')}>Next</button>
    </div>
  );
}

export default Step2;