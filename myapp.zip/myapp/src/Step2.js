import React from "react";
import { useNavigate } from "react-router-dom";

export default function Step2({ formData, setFormData }) {
  const navigate = useNavigate();

  const carCompanies = ["Toyota", "Suzuki", "Haval"];

  return (
    <div style={{ width: "70%", margin: "auto" }}>
      <h2>Vehicle Information</h2>

      <input
        style={{ width: "100%" }}
        placeholder="Registration No of Vehicle"
        value={formData.regNumber}
        onChange={(e) => setFormData({ ...formData, regNumber: e.target.value })}
      />

      <br /><br />


      <input
        style={{ width: "100%" }}
        placeholder="Number Etched into Windows"
        value={formData.windowNumber}
        onChange={(e) => setFormData({ ...formData, windowNumber: e.target.value })}
      />

      <br /><br />

      <input
        style={{ width: "100%" }}
        placeholder="Chassis / VIN Number (17 Digits)"
        value={formData.chassisNumber}
        onChange={(e) => setFormData({ ...formData, chassisNumber: e.target.value })}
      />

      <br /><br />

      <select
        style={{ width: "100%" }}
        value={formData.make}
        onChange={(e) => setFormData({ ...formData, make: e.target.value })}
      >
        <option>Select Make</option>
        {carCompanies.map((c) => (
          <option key={c}>{c}</option>
        ))}
      </select>

      <br /><br />

      <div style={{ display: "flex", gap: "10px" }}>
        <input
          style={{ flex: 1 }}
          placeholder="Model"
          value={formData.model}
          onChange={(e) => setFormData({ ...formData, model: e.target.value })}
        />

        <input
          style={{ flex: 1 }}
          placeholder="Colour"
          value={formData.color}
          onChange={(e) => setFormData({ ...formData, color: e.target.value })}
        />
      </div>

      <br />

      <div style={{ display: "flex", gap: "10px" }}>
        <input
          style={{ flex: 1 }}
          placeholder="Year"
          value={formData.year}
          onChange={(e) => setFormData({ ...formData, year: e.target.value })}
        />

        <input
          style={{ flex: 1 }}
          placeholder="Current Mileage"
          value={formData.mileage}
          onChange={(e) => setFormData({ ...formData, mileage: e.target.value })}
        />
      </div>

      <br />

      <input
        style={{ width: "100%" }}
        placeholder="Alarm Type"
        value={formData.alarmType}
        onChange={(e) => setFormData({ ...formData, alarmType: e.target.value })}
      />

      <br /><br />

      <div style={{ display: "flex", gap: "10px" }}>
        <input
          style={{ flex: 1 }}
          placeholder="Dealer First Name"
          value={formData.dealerFirstName}
          onChange={(e) => setFormData({ ...formData, dealerFirstName: e.target.value })}
        />

        <input
          style={{ flex: 1 }}
          placeholder="Dealer Last Name"
          value={formData.dealerLastName}
          onChange={(e) => setFormData({ ...formData, dealerLastName: e.target.value })}
        />
      </div>

      <br />

      <input
        style={{ width: "100%" }}
        placeholder="Dealer Town"
        value={formData.dealerTown}
        onChange={(e) => setFormData({ ...formData, dealerTown: e.target.value })}
      />

      <br /><br />

      <div style={{ display: "flex", gap: "10px" }}>
        <button onClick={() => navigate("/")} style={{ flex: 1, padding: "10px" }}>
          Back
        </button>

        <button onClick={() => navigate("/summary")} style={{ flex: 1, padding: "10px" }}>
          Next
        </button>
      </div>
    </div>
  );
}
