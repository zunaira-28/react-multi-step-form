import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Summary from "./Summary";

function App() {
  const [formData, setFormData] = useState({
    // Step 1 Fields
    firstName: "",
    lastName: "",
    title: "",
    companyName: "",
    country: "",
    province: "",
    city: "",
    postcode: "",
    homePhone: "",
    mobilePhone: "",
    fax: "",
    email: "",
    acknowledge: false,

    // Step 2 Fields
    regNumber: "",
    windowNumber: "",
    chassisNumber: "",
    make: "",
    model: "",
    color: "",
    year: "",
    mileage: "",
    alarmType: "",
    dealerFirstName: "",
    dealerLastName: "",
    dealerTown: ""
  });

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Step1 formData={formData} setFormData={setFormData} />} />
        <Route path="/step2" element={<Step2 formData={formData} setFormData={setFormData} />} />
        <Route path="/summary" element={<Summary formData={formData} />} />
      </Routes>
    </Router>
  );
}

export default App;
