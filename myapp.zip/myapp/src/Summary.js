  import React from 'react';
import { useNavigate } from 'react-router-dom';

function Summary({ formData }) {
  const navigate = useNavigate();

  return (
    <div className="form-container">
      <h2>Profile Summary</h2>
      <pre>{JSON.stringify(formData, null, 2)}</pre>
      <button onClick={() => navigate('/')}>Start Over</button>
    </div>
  );
}

export default Summary;