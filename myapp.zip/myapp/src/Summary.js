import React from "react";

export default function Summary({ formData }) {
  return (
    <div style={{ width: "70%", margin: "auto" }}>
      <h2>Summary</h2>
      <pre>{JSON.stringify(formData, null, 2)}</pre>
      <button style={{ padding: "10px 20px" }}>Submit</button>
    </div>
  );
}
