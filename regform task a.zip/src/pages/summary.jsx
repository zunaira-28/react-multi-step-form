import React from "react";
import { useNavigate } from "react-router-dom";

export default function Summary({ form, setStep }) {
  const nav = useNavigate();

  // Edit goes back to Step1
  const editInfo = () => {
    setStep(1);
    nav("/"); // or "/step1" if your route is Step1
  };

  // Confirm goes to Success page
  const submit = () => {
    setStep("success");
    nav("/success");
  };

  // Row component for display
  const Row = ({ label, value }) => (
    <div className="row">
      <span className="label">{label}</span>
      <span className="value">{value}</span>
    </div>
  );

  return (
    <div className="card notebook">
      <h2 className="title">Review Your Details</h2>
      <div className="receipt-box">
        <Row label="Name:" value={form.name} />
        <Row label="Email:" value={form.email} />
        <Row label="Age:" value={form.age} />
        {form.gender && <Row label="Gender:" value={form.gender} />}

        <Row label="Country:" value={form.country} />
        <Row label="City:" value={form.city} />

        <Row label="Username:" value={form.username} />
        <Row
          label="Hobbies:"
          value={
            <>
              {form.hobbies?.join(", ")}
              {form.otherHobby && `, ${form.otherHobby}`}
            </>
          }
        />
        <Row
          label="📩 Newsletter:"
          value={form.newsletter ? "Subscribed 💌" : "No"}
        />
      </div>

      <div className="btns">
        <button className="btn back" onClick={editInfo}>
          Edit
        </button>
        <button className="btn" onClick={submit}>
          Confirm
        </button>
      </div>

      {/* Styles */}
      <style>{`
        .notebook {
          max-width: 450px;
          margin: 40px auto;
          padding: 25px 20px;
          background: #ffffffff; /* soft pink */
          border-radius: 20px;
          box-shadow: 0 8px 25px rgba(255,182,193,0.3); /* pinkish shadow */
          border: 2px dashed #ffb6c1; /* light pink dashed border */
          font-family: 'Comic Sans MS', 'Comic Neue', cursive;
          animation: fadeIn 0.5s ease;
        }

        .title {
          text-align: center;
          margin-bottom: 20px;
          color: #ff69b4; /* hot pink title */
        }

        .receipt-box {
          display: flex;
          flex-direction: column;
        }

        .row {
          display: flex;
          justify-content: space-between;
          padding: 8px 0;
        }

        .row + .row {
          border-top: 1px dotted #ffb6c1; /* pink dotted lines */
        }

        .label {
          font-weight: 600;
          color: #0e0d0dff;
        }

        .value {
          font-weight: 500;
          color: #0e0d0dff;
        }

        .btns {
          display: flex;
          justify-content: space-between;
          margin-top: 25px;
        }

        .btn {
          background: #ffb6c1; /* pastel pink button */
          border: none;
          padding: 10px 20px;
          border-radius: 12px;
          cursor: pointer;
          font-weight: 600;
          transition: transform 0.2s, box-shadow 0.2s;
          color: #fff;
        }

        .btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 15px rgba(255,105,180,0.3);
        }

        .btn.back {
          background: #ffcce6;
          color: #ff1a75;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
