import React from "react";

export default function Review({ form }) {
  return (
    <div className="card fade-in">
      <h2> Final Receipt</h2>

      <div className="receipt big">
        <h3>Customer Information</h3>
        <p><b>Name:</b> {form.name}</p>
        <p><b>Email:</b> {form.email}</p>
        <p><b>Age:</b> {form.age}</p>

        
        <p><b>Country:</b> {form.country}</p>
        <p><b>City:</b> {form.city}</p>
        <li><b>Username:</b> {form.username}</li>
        <p><b>Preferences:</b> {form.preferences.join(", ")}</p>
        
        <p className="thanks">🌸 Thank you for submitting! 🌸</p>
      </div>
    </div>
  );
}
