import React, { useState, useEffect } from "react";




import {  Routes, Route } from "react-router-dom";
import Step1 from "./pages/step1";
import Step2 from "./pages/step2";
import Step3 from "./pages/step3";
import Step4 from "./pages/step4";
import Summary from "./pages/summary";
import Review from "./pages/Review";
import ProgressBar from "./components/ProgressBar";
import "./styles/form.css";
import Success from "./pages/success";

export default function App() {
  const [form, setForm] = useState(() => {
    return JSON.parse(localStorage.getItem("formData")) || {
      name: "",
      email: "",
      age: "",
      country: "",
      city: "",
      username: "",
      password: "",
      confirmPassword: "",
      preferences: [],
    };
  });

  const [step, setStep] = useState(() => {
    return Number(localStorage.getItem("currentStep")) || 1;
  });

  useEffect(() => {
    localStorage.setItem("formData", JSON.stringify(form));
    localStorage.setItem("currentStep", step);
  }, [form, step]);

  return (
   
      <div className="app-container">
       <ProgressBar step={step} totalSteps={4} />


        <Routes>
          <Route
            path="/"
            element={<Step1 form={form} setForm={setForm} setStep={setStep} />}
          />
          <Route
            path="/step2"
            element={<Step2 form={form} setForm={setForm} setStep={setStep} />}
          />
          <Route
            path="/step3"
            element={<Step3 form={form} setForm={setForm} setStep={setStep} />}
          />
          <Route
            path="/step4"
            element={<Step4 form={form} setForm={setForm} setStep={setStep} />}
          />
          <Route path="/summary" element={<Summary form={form} setStep={setStep} />} />
          <Route path="/Review" element={<Review form={form} setStep={setStep} />} />
          <Route path="/success" element={<Success setStep={setStep} setForm={setForm} />}
 />
        </Routes>
      </div>
  
  );
}
