# Task 4 - Data Seeding with Faker.js

This project demonstrates **data seeding** for MongoDB collections using **Faker.js**.
It includes the following collections: `user`, `preference`, `location`, `analytics`.

---

## Prerequisites

* Node.js installed
* MongoDB Atlas account or local MongoDB server
* MongoDB Compass (optional, to view data)

---

## Setup

1. **Install dependencies**

```bash
npm install
```

2. **Create your `.env` file**
   Copy `.env.example` and rename it to `.env`, then add your MongoDB connection string:

```
MONGO_URI=your_mongodb_connection_string
PORT=5000
```

---

## Run the Seeder

```bash
node seeders/seedData.js
```

* This will generate **dummy data** and insert it into your MongoDB database.
* The collections will automatically be created if they don’t exist.

---

## View Data

* Open **MongoDB Compass**
* Connect using your MongoDB connection string
* You should see the following collections filled with data:

  * `user`
  * `preference`
  * `location`
  * `analytics`

---

## Notes

* Data is **auto-generated using Faker.js**.
* Types of data don’t matter — the purpose is to **show seeding works**.
* No frontend or multi-step registration form is required for Task 4.
* Include `.env.example` in the ZIP, **do not include your actual `.env` file**.
