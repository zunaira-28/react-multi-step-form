const mongoose = require("mongoose");

const analyticsSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    action: {
      type: String,
      enum: ["login", "search", "view", "logout"],
      required: true,
    },
    device: {
      type: String,
      enum: ["mobile", "desktop"],
      required: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
  }
);

module.exports = mongoose.model("Analytics", analyticsSchema);
