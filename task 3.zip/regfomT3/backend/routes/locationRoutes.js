const express = require("express");
const {
  getLocations,
  getCitiesByCountry,
} = require("../controllers/locationController");

const router = express.Router();

router.get("/", getLocations);
router.get("/:country", getCitiesByCountry);

module.exports = router;
