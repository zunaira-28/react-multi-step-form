import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { countryCityData } from "../data/locations"; // your countries/cities

export default function Step2({ form, setForm, setStep }) {
  const nav = useNavigate();
  const [error, setError] = useState("");

  const next = () => {
    if (!form.country || !form.city) {
      setError("Please select country and city");
      return;
    }
    setError("");
    setStep(3);
    nav("/step3");
  };

  const back = () => {
    setStep(1);
    nav("/");
  };

  return (
    <div className="card fade-slide">
      <h2>Step 2: Location</h2>
      {error && <p className="error">{error}</p>}

      <div className="box">
        <label>Country*</label>
        <select
          value={form.country}
          onChange={(e) => setForm({ ...form, country: e.target.value, city: "" })}
        >
          <option value="">Select…</option>
          {Object.keys(countryCityData).map(c => <option key={c}>{c}</option>)}
        </select>
      </div>

      <div className="box">
        <label>City*</label>
        <select
          value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })}
        >
          <option value="">Select…</option>
          {form.country && countryCityData[form.country].map(c => <option key={c}>{c}</option>)}
        </select>
      </div>

      <div className="btns">
        <button className="btn back" onClick={back}>Back</button>
        <button className="btn" onClick={next}>Next</button>
      </div>
    </div>
  );
}
